<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search">
	<input type="text" name="s" id="widget-search" />
</form>