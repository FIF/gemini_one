<?php

class FileEntry extends Eloquent {

	protected $table = 'files';


}
